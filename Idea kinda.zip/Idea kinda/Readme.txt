سلام خسته نباشید
خروجی ها به صورت فایلی هستند که دراین دایرکتوری قرار دارند
بالای هرکد یک خط توضیح نوشتم
این را با mysql زدم
لطفا connectionString و new MySqlConnection(connectionString) را با توجه به دیتابیس خود تغییر دهد
از انجایی که در فایل نوشتید از فایل دیگر بخواند دیگر از 
dbcontext نساختم
به دلیل کوچک بود پروژه تمامی کد را داخل فایل 
Form1.cs قرار دارد
دراین فایل 4 کلاس وجود دارد 
Form1 و Data و get_Data و Drow
Data برای شی گرایی ساختم
get_Data برای دریافت دیتا ها از کد یا دیتابیس 
Drow  برای رسم زوایا و اشکال هندسی

از این دستورات برای ایجاد دیتابیس استفاده کنید

باتوجه نوع دیتابیس خود این دستورات را تغییر دهید


CREATE TABLE Data (
    ->     ID int PRIMARY KEY AUTO_INCREMENT,
    ->     Name varchar(255),
    ->     X int,
    ->     Y int,
    ->     R int,
    ->     HBW int,
    ->     Azimuth int
    -> );
Query OK, 0 rows affected (0.03 sec)

mysql> show columns from Data;
+---------+--------------+------+-----+---------+----------------+
| Field   | Type         | Null | Key | Default | Extra          |
+---------+--------------+------+-----+---------+----------------+
| ID      | int          | NO   | PRI | NULL    | auto_increment |
| Name    | varchar(255) | YES  |     | NULL    |                |
| X       | int          | YES  |     | NULL    |                |
| Y       | int          | YES  |     | NULL    |                |
| R       | int          | YES  |     | NULL    |                |
| HBW     | int          | YES  |     | NULL    |                |
| Azimuth | int          | YES  |     | NULL    |                |
+---------+--------------+------+-----+---------+----------------+
7 rows in set (0.47 sec)
---------------------------------------------------------

mysql> INSERT INTO Data (Name, X, Y,R,HBW,Azimuth)VALUES ("A", 100, 100, 50,50,30);
Query OK, 1 row affected (0.19 sec)

mysql> INSERT INTO Data (Name, X, Y,R,HBW,Azimuth)VALUES ("B", 400, 100, 70,65,0);
Query OK, 1 row affected (0.01 sec)

mysql> INSERT INTO Data (Name, X, Y,R,HBW,Azimuth)VALUES ("C", 300, 500, 47,45,120);
Query OK, 1 row affected (0.01 sec)

mysql> INSERT INTO Data (Name, X, Y,R,HBW,Azimuth)VALUES ("D", 400, 200, 100,50,270);
Query OK, 1 row affected (0.01 sec)

mysql> INSERT INTO Data (Name, X, Y,R,HBW,Azimuth)VALUES ("E", 200, 238, 74,55,180);
Query OK, 1 row affected (0.01 sec)

mysql> select * from data
    -> ;
+----+------+------+------+------+------+---------+
| ID | Name | X    | Y    | R    | HBW  | Azimuth |
+----+------+------+------+------+------+---------+
|  1 | A    |  100 |  100 |   50 |   50 |      30 |
|  2 | B    |  400 |  100 |   70 |   65 |       0 |
|  3 | C    |  300 |  500 |   47 |   45 |     120 |
|  4 | D    |  400 |  200 |  100 |   50 |     270 |
|  5 | E    |  200 |  238 |   74 |   55 |     180 |
+----+------+------+------+------+------+---------+
5 rows in set (0.00 sec)

mysql>