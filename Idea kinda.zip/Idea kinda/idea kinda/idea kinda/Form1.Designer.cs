﻿namespace idea_kinda
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            JPG = new Button();
            EXEL = new Button();
            DROW = new Button();
            button1 = new Button();
            SuspendLayout();
            // 
            // JPG
            // 
            JPG.Location = new Point(467, 520);
            JPG.Name = "JPG";
            JPG.Size = new Size(94, 29);
            JPG.TabIndex = 0;
            JPG.Text = "JPG";
            JPG.UseVisualStyleBackColor = true;
            JPG.Click += button1_Click;
            // 
            // EXEL
            // 
            EXEL.Location = new Point(273, 520);
            EXEL.Name = "EXEL";
            EXEL.Size = new Size(94, 29);
            EXEL.TabIndex = 1;
            EXEL.Text = "EXEL";
            EXEL.UseVisualStyleBackColor = true;
            EXEL.Click += EXEL_Click;
            // 
            // DROW
            // 
            DROW.Location = new Point(357, 456);
            DROW.Name = "DROW";
            DROW.Size = new Size(121, 29);
            DROW.TabIndex = 2;
            DROW.Text = "HORD CODE";
            DROW.UseVisualStyleBackColor = true;
            DROW.Click += DROW_Click;
            // 
            // button1
            // 
            button1.Location = new Point(357, 597);
            button1.Name = "button1";
            button1.Size = new Size(121, 29);
            button1.TabIndex = 3;
            button1.Text = "DATABASS";
            button1.UseVisualStyleBackColor = true;
            button1.Click += DROW_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 800);
            Controls.Add(button1);
            Controls.Add(DROW);
            Controls.Add(EXEL);
            Controls.Add(JPG);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button JPG;
        private Button EXEL;
        private Button DROW;
        private Button button1;
    }
}
