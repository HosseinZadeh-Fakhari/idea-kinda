﻿using MySql.Data.MySqlClient;
using OfficeOpenXml;
using System.Data;
using System.Drawing;
using System.Xml.Linq;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace idea_kinda
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            int width = 800; 
            int height = 800;   

            // use bitmap for create image 
            using (Bitmap bitmap = new Bitmap(width, height))
            {
                using (Graphics g = Graphics.FromImage(bitmap))
                {
                    // drow all sector
                    g.Clear(Color.White);
                    new Drow(g, sender);

                }
                try
                {
                    //save this location
                    bitmap.Save(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\Im Here.jpg", System.Drawing.Imaging.ImageFormat.Jpeg);
                    MessageBox.Show("ذخیره با موفقیت انجام شد!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("خطا در ذخیره: " + ex.Message);
                }

            }
        }

        private void DROW_Click(object sender, EventArgs e)
        {
            // this metod work when click Drow botton
            Graphics g = this.CreateGraphics();

            // drow all sector
            new Drow(g ,sender);

        }

        private void EXEL_Click(object sender, EventArgs e)
        {


            try
            {
                //get data from getdata class
                get_Data get_Data = new get_Data();
                var DATA = get_Data.Hard_Code();


                // add columns for exel
                DataTable dt = new DataTable();
                dt.Columns.Add("Name");
                dt.Columns.Add("X");
                dt.Columns.Add("Y");
                dt.Columns.Add("R");
                dt.Columns.Add("HBW");
                dt.Columns.Add("Azimuth");


                // add rows in exel
                foreach (Data data in DATA)
                {
                    dt.Rows.Add(data.Name, data.X, data.Y, data.R, data.HBW, data.Azimuth);
                }


                // use epplus for create exel file
                using (ExcelPackage package = new ExcelPackage())
                {
                    ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Sheet1");
                    worksheet.Cells["A1"].LoadFromDataTable(dt, true);

                    // seve in this location
                    string filePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Im Here.xlsx");

                    FileInfo fi = new FileInfo(filePath);
                    package.SaveAs(fi);
                }

                MessageBox.Show("خروجی در MyDocuments ذخیره شد!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطا در ذخیره: " + ex.Message);
            }
        }
    }



    public class Data
    {

        public int ID { get; set;}
        public string Name { get; set;}
        public int X{ get; set;}
        public int Y{ get; set;}
        public int R{ get; set;}
        public int HBW{ get; set;}
        public int Azimuth{ get; set;}

    }

    public class get_Data
    {

        public  List<Data> Hard_Code()
        {
            // Creates a list of data
           List<Data> data = new List<Data>();

           data.Add(new Data{Name = "A",X = 100,Y = 100,R = 50,HBW = 50,Azimuth = 30,});
           data.Add(new Data{Name = "B",X = 400,Y = 100,R = 70,HBW = 65,Azimuth = 0,});
           data.Add(new Data{Name = "C",X = 300,Y = 500,R = 47,HBW = 45,Azimuth = 120,});
           data.Add(new Data{Name = "D",X = 400,Y = 200,R = 100,HBW = 50,Azimuth = 270,});
           data.Add(new Data{Name = "E",X = 200,Y = 238,R = 74,HBW = 55,Azimuth = 180,});

           return data;

        }
        public List<Data> Mysql()
        {


            List<Data> data = new List<Data>();

            // connection string config of my database
            string connectionString = "Server=localhost;Database=ideakinda;password=Amir1381;user=root;port=3306";

            // try to connect
            using (var connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    MessageBox.Show("Connection successful!");

                    // query for fetch from db
                    string query = "SELECT * FROM Data";

                    using (var command = new MySqlCommand(query, connection))
                    {
                        
                        using (var reader = command.ExecuteReader())
                        {
                            var s = reader.Read(); 
                            while (reader.Read())
                            {
                                // reader[0].ToString() ==> "A",int.Parse(reader[2].ToString()) ==> 100
                                data.Add(new Data() { 
                                    ID= int.Parse(reader[0].ToString()), 
                                    Name = reader[1].ToString(),
                                    X = int.Parse(reader[2].ToString()),
                                    Y = int.Parse(reader[3].ToString()),
                                    R = int.Parse(reader[4].ToString()),
                                    HBW = int.Parse(reader[5].ToString()),
                                    Azimuth = int.Parse(reader[6].ToString()),

                                });
                                
                            }
                        }
                    }

                    connection.Close();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }


            return data;


        }
    }

    public class Drow
    {

        public Drow(Graphics g , object sender)
        {
            get_Data get_Data = new get_Data();
            var data = new List<Data>();

            // form has 2 btn : DATABASE , HARD CODE
            if (sender is Button button)
            {
                string text = button.Text;

                if (text == "DATABASS") { data = get_Data.Mysql(); }
                else {  data = get_Data.Hard_Code();}
            }


            if (data != null)
            {
                Sector_line(g, data);
                Radius_line(g, data);

                North_line(g, data);

                
            }


        }


        
        private void Sector_line(Graphics g, List<Data> DATA) {

            // Windows draws the sector clockwise, so it must be reversed

            foreach (Data data in DATA)
            {

                // start sector
                float start_sector = -(90-(data.Azimuth + data.HBW / 2));  
                // end sector
                float end_sector = -data.HBW; 

                // drow Sector   
                g.FillPie(Brushes.Pink, data.X - data.R, data.Y - data.R, data.R * 2,
                    data.R * 2, start_sector, end_sector);

                // Angle bisector
                float midAngle = start_sector + end_sector / 2; 
                float endX = data.X + data.R * (float)Math.Cos(midAngle * Math.PI / 180);
                float endY = data.Y + data.R * (float)Math.Sin(midAngle * Math.PI / 180);

                // drow Angle bisector
                g.DrawLine(Pens.Blue, data.X, data.Y, endX, endY);

                // The first side of the angle
                float endXStart = data.X + (data.R * (float)Math.Cos(start_sector * Math.PI / 180));
                float endYStart = data.Y + (data.R * (float)Math.Sin(start_sector * Math.PI / 180));

                // The second side of the angle  
                float endXSweep = data.X + data.R * (float)Math.Cos((start_sector + end_sector) * Math.PI / 180);
                float endYSweep = data.Y + data.R * (float)Math.Sin((start_sector + end_sector) * Math.PI / 180);

                // drow beginning and end lines
                g.DrawLine(Pens.Purple, data.X, data.Y, endXStart, endYStart);
                g.DrawLine(Pens.Purple, data.X, data.Y, endXSweep, endYSweep);


                //////////////////////////////////////////////////////////////////////////////

                Font drawFont = new Font("Arial", 15);

                // Create a brush to draw the text  
                SolidBrush drawBrush = new SolidBrush(Color.Black);

                // Draw the text  
                g.DrawString(data.Name, drawFont, drawBrush, data.X+data.R+20, data.Y - 20);



            }
        }

        private void North_line(Graphics g, List<Data> DATA)
        {

            foreach (Data data in DATA)
            {
                Pen pen = new Pen(Color.Black, 3);

                // first point
                Point start = new Point(data.X, data.Y);
                // second point (upper than start)
                Point end = new Point(data.X, data.Y - 70);
                // create triangle
                // second point for triangle
                Point second_triangle_point = new Point(data.X + 13, data.Y - 70 + 15);
                // third point for triangle
                Point third_triangle_point = new Point(data.X - 13, data.Y - 70 + 15);

                //drow  
                g.DrawLine(pen, start, end);

                Point first_triangle_point = new Point(data.X, data.Y - 70 - 3);

                Point[] triangle = { first_triangle_point, second_triangle_point, third_triangle_point };
                // drow triangle
                g.FillPolygon(Brushes.Red, triangle);
            }
        }
        private void Radius_line(Graphics g, List<Data> DATA)
        {            // ofoghy y==0

            foreach (Data data in DATA)
            {
                Pen pen = new Pen(Color.Orange, 3);

                // first point
                Point start = new Point(data.X, data.Y);
                // second point (right than start)
                Point end = new Point(data.X + data.R, data.Y);
                // create triangle
                // second point for triangle
                Point second_triangle_point = new Point(data.X + data.R - 15, data.Y + 13); // نوک فلش (سمت چپ)  
                Point third_triangle_point = new Point(data.X + data.R - 15, data.Y - 13); // نوک فلش (سمت راست)  

                //drow  
                g.DrawLine(pen, start, end);

                Point[] triangle = { end, second_triangle_point, third_triangle_point };
                // drow triangle
                g.FillPolygon(Brushes.Red, triangle);
            }
        }
    }


}